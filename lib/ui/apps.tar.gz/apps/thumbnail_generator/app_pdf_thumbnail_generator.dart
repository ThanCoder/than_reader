import 'package:t_pdf_reader/t_pdf_reader.dart';
import 'package:than_reader/ui/apps/thumbnail_generator/i_thumbnail_generator.dart';

class AppPdfThumbnailGenerator implements IThumbnailGenerator {
  @override
  Future<bool> generate(
    String inputPath,
    String outPath, {
    int pageIndex = 0,
    int width = 200,
    int height = 200,
    int quality = 70,
    String? password,
  }) async {
    return await PdfThumbnailGenerator.instance.generate(
      inputPath,
      outPath,
      width: width,
      height: height,
      quality: 90,
    );
    // if (Platform.isLinux) {
    // return await PdfThumbnailGenerator.instance.generate(
    //   inputPath,
    //   outPath,
    //   width: width,
    //   height: height,
    //   quality: 90,
    // );
    // } else {
    //   return await ThanPkgAndroid.getInstance.pdfHandler.saveToThumbnail(
    //     pdfPathOrUri: inputPath,
    //     targetPath: outPath,
    //   );
    // }
  }
}
